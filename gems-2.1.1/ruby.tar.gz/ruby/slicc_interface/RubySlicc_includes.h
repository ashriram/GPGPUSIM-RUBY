#ifndef RUBYSLICC_INCLUDES_H
#define RUBYSLICC_INCLUDES_H

#include "RubySlicc_ComponentMapping.h"
#include "RubySlicc_Util.h"
#include "RubySlicc_Profiler_interface.h"

#endif

